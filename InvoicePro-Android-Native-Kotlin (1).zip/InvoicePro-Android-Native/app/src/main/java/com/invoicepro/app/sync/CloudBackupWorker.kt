package com.invoicepro.app.sync

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.invoicepro.app.data.local.AppDatabase

class CloudBackupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    private val TAG = "CloudBackupWorker"

    override suspend fun doWork(): Result {
        Log.i(TAG, "Executing scheduled Room SQLite database cloud backup...")

        val account = GoogleSignIn.getLastSignedInAccount(applicationContext)
        if (account == null) {
            Log.w(TAG, "No Google account signed in. Skipping automated cloud backup.")
            return Result.success()
        }

        return try {
            val database = AppDatabase.getInstance(applicationContext)
            val syncManager = GoogleDriveSyncManager(applicationContext)

            val result = syncManager.backupRoomDatabaseToDrive(database, account)
            if (result.isSuccess) {
                Log.i(TAG, "Periodic Google Drive backup completed: ${result.getOrNull()?.fileName}")
                Result.success()
            } else {
                Log.e(TAG, "Periodic backup failed", result.exceptionOrNull())
                Result.retry()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during Room cloud backup work", e)
            Result.failure()
        }
    }
}
