package com.invoicepro.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val name: String,
    val sku: String? = null,
    val unitPrice: Double,
    val unit: String = "pcs",
    val taxPercent: Double = 15.0,
    val description: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
