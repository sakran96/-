package com.invoicepro.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val companyName: String? = null,
    val email: String,
    val phone: String,
    val taxNumber: String? = null,
    val address: String,
    val city: String? = null,
    val country: String? = null,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
