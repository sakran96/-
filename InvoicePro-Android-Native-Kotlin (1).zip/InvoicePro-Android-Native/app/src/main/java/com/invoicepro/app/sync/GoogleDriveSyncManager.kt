package com.invoicepro.app.sync

import android.content.Context
import android.util.Log
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.client.extensions.android.http.AndroidHttp
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.ByteArrayContent
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File
import com.google.gson.Gson
import com.invoicepro.app.data.local.AppDatabase
import com.invoicepro.app.data.local.entities.InvoiceEntity
import com.invoicepro.app.data.local.entities.CustomerEntity
import com.invoicepro.app.data.local.entities.ProductEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale

class GoogleDriveSyncManager(private val context: Context) {

    private val gson = Gson()
    private val TAG = "GoogleDriveSync"

    data class RoomDatabaseBackupPayload(
        val version: String = "1.0",
        val schemaVersion: String = "room_sqlite_v1",
        val timestamp: String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date()),
        val device: String = android.os.Build.MODEL ?: "Android Device",
        val invoices: List<InvoiceEntity>,
        val customers: List<CustomerEntity>,
        val products: List<ProductEntity>
    )

    data class CloudSnapshotInfo(
        val fileId: String,
        val fileName: String,
        val createdTime: String,
        val sizeBytes: Long,
        val description: String?
    )

    fun getGoogleSignInClient(): GoogleSignInClient {
        val signInOptions = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(
                Scope(DriveScopes.DRIVE_FILE),
                Scope(DriveScopes.DRIVE_APPDATA)
            )
            .build()
        return GoogleSignIn.getClient(context, signInOptions)
    }

    private fun getDriveService(account: GoogleSignInAccount): Drive {
        val credential = GoogleAccountCredential.usingOAuth2(
            context,
            Collections.singleton(DriveScopes.DRIVE_FILE)
        ).apply {
            selectedAccount = account.account
        }

        return Drive.Builder(
            AndroidHttp.newCompatibleTransport(),
            GsonFactory.getDefaultInstance(),
            credential
        ).setApplicationName("InvoicePro-Android").build()
    }

    suspend fun backupRoomDatabaseToDrive(
        database: AppDatabase,
        account: GoogleSignInAccount
    ): Result<CloudSnapshotInfo> = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(account)
            val invoices = database.invoiceDao().getAllInvoicesSync()
            val customers = database.customerDao().getAllCustomersSync()
            val products = database.productDao().getAllProductsSync()

            val payload = RoomDatabaseBackupPayload(
                invoices = invoices,
                customers = customers,
                products = products
            )
            val jsonString = gson.toJson(payload)
            val contentBytes = jsonString.toByteArray(Charsets.UTF_8)

            val timeString = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
            val metadata = File().apply {
                name = "invoicepro_backup_${timeString}.json"
                mimeType = "application/json"
                description = "Invoice Pro Room Backup (Invoices: ${invoices.size}, Customers: ${customers.size}, Products: ${products.size})"
            }

            val mediaContent = ByteArrayContent("application/json", contentBytes)
            val uploadedFile = driveService.files().create(metadata, mediaContent)
                .setFields("id, name, createdTime, size, description")
                .execute()

            Result.success(
                CloudSnapshotInfo(
                    fileId = uploadedFile.id,
                    fileName = uploadedFile.name,
                    createdTime = uploadedFile.createdTime?.toString() ?: "",
                    sizeBytes = uploadedFile.getSize() ?: contentBytes.size.toLong(),
                    description = uploadedFile.description
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to backup Room database to Google Drive", e)
            Result.failure(e)
        }
    }

    suspend fun listCloudBackups(account: GoogleSignInAccount): Result<List<CloudSnapshotInfo>> =
        withContext(Dispatchers.IO) {
            try {
                val driveService = getDriveService(account)
                val query = "name contains 'invoicepro_backup_' and trashed = false"

                val result = driveService.files().list()
                    .setQ(query)
                    .setOrderBy("createdTime desc")
                    .setFields("files(id, name, createdTime, size, description)")
                    .execute()

                val list = result.files.map { file ->
                    CloudSnapshotInfo(
                        fileId = file.id,
                        fileName = file.name,
                        createdTime = file.createdTime?.toString() ?: "",
                        sizeBytes = file.getSize() ?: 0L,
                        description = file.description
                    )
                }

                Result.success(list)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to list cloud backups", e)
                Result.failure(e)
            }
        }

    suspend fun restoreRoomDatabaseFromDrive(
        fileId: String,
        database: AppDatabase,
        account: GoogleSignInAccount
    ): Result<RoomDatabaseBackupPayload> = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(account)
            val outputStream = ByteArrayOutputStream()

            driveService.files().get(fileId).executeMediaAndDownloadTo(outputStream)
            val jsonContent = outputStream.toString("UTF-8")
            val payload = gson.fromJson(jsonContent, RoomDatabaseBackupPayload::class.java)

            database.runInTransaction {
                payload.customers.forEach { database.customerDao().insertCustomerSync(it) }
                payload.products.forEach { database.productDao().insertProductSync(it) }
                payload.invoices.forEach { database.invoiceDao().insertInvoiceSync(it) }
            }

            Result.success(payload)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to restore Room DB from Google Drive", e)
            Result.failure(e)
        }
    }
}
