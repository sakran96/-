package com.invoicepro.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.invoicepro.app.data.local.converters.InvoiceTypeConverters
import java.math.BigDecimal

enum class InvoiceType {
    SALES, SERVICES, TAX_INVOICE, QUOTATION, RECEIPT
}

enum class PaymentStatus {
    PAID, PARTIALLY_PAID, UNPAID, OVERDUE
}

data class LineItem(
    val id: String,
    val productId: String? = null,
    val description: String,
    val quantity: Double,
    val unitPrice: Double,
    val unit: String = "pcs",
    val discountPercent: Double = 0.0,
    val taxPercent: Double = 0.0,
    val total: Double
)

@Entity(tableName = "invoices")
@TypeConverters(InvoiceTypeConverters::class)
data class InvoiceEntity(
    @PrimaryKey val id: String,
    val invoiceNumber: String,
    val type: InvoiceType,
    val customerId: String,
    val customerName: String,
    val customerCompany: String?,
    val customerEmail: String,
    val customerPhone: String,
    val customerTaxNumber: String?,
    val customerAddress: String,
    val issueDate: String,
    val dueDate: String,
    val currency: String = "SAR",
    val currencySymbol: String = "ر.س",
    val items: List<LineItem>,
    val subtotal: Double,
    val overallDiscountType: String = "percent",
    val overallDiscountValue: Double = 0.0,
    val overallDiscountAmount: Double = 0.0,
    val taxPercent: Double = 15.0,
    val taxAmount: Double = 0.0,
    val shippingFee: Double = 0.0,
    val grandTotal: Double,
    val paidAmount: Double = 0.0,
    val balanceDue: Double,
    val status: PaymentStatus,
    val templateId: String = "modern",
    val primaryColor: String = "#2563EB",
    val notes: String? = null,
    val terms: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
